import React from 'react';
import Counter from '../../components/counter';

const CounterPage = () =>
  <div>
    <Counter />
  </div>;

export default CounterPage;
